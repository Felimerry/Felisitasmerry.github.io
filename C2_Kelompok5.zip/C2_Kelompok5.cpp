#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>
using namespace std;

string loop;
int panjangList; 

struct pendaftar{
	string nama,asal,nik,nohp;
	
};

struct tamu{
    string nama,instansi,tujuan,hp;
    
};

struct Node {
	pendaftar data;
	tamu data1;
	
	string nama;
    string agm;
    string pgt;
    string hp;
	
	Node *next;
};

void gotoxy(int x, float y){
	COORD c;
	c.X=x;
	c.Y=y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);
}

//membuat node baru
void insert(Node** head_ref, string new_nama, string new_agm, string new_pgt, string new_hp) {
    Node* new_node = new Node();
    new_node->nama = new_nama;
    new_node->agm = new_agm;
    new_node->pgt = new_pgt;
    new_node->hp = new_hp;
    new_node->next = *head_ref;
    *head_ref = new_node;
}

// menampilkan data dari linklist
void printList(Node* n) {
    int no = 0;
    while (n != NULL) {
        cout << " Penghuni Kamar["<<no<<"]" << endl;
        cout << " Nama             : " << n->nama << endl;
        cout << " Agama            : " << n->agm << endl;
        cout << " Perguruan Tinggi : " << n->pgt << endl;
        cout << " No.Hp            : " << n->hp << endl;
        cout << " ========================================" << endl;
        no++;
        n = n->next;
    }
}

void asrama(){
    // Read data file csv
    ifstream file("coba.csv");  
    if(!file.is_open()) {
        cout << " eror " << endl;
        return;
    } 
	cout << " ==========================================" << endl;
    cout << "            Data Penghuni Asrama           " << endl;
    cout << " ==========================================" << endl;

    
    Node* head = NULL;

    // membaca csv dan menampilkan dari file csv
    string nama, agm, pgt, hp;
    while (file.good()){  
        getline(file,nama,',');
        getline(file,agm,',');
        getline(file,pgt,',');
        getline(file,hp,'\n');

        insert(&head, nama, agm, pgt, hp);
    }  

    file.close();

    // Print the data of the linked list
    printList(head);
    system("pause");
}


// menambahkan data ke CSV pada menu 2
void tambah_data(string nama, string agm, string pgt, string hp){
    ofstream file("coba.csv", ios::app); // Buka file dengan mode append

    if(!file.is_open()){
        cout << "Gagal membuka file" << endl;
        return;
    }

    file << nama << "," << agm << "," << pgt << "," << hp << endl;
    file.close();
}

void menu2(){
    string nama, agm, pgt, hp; fflush(stdin);
    gotoxy(45,3);cout << "============================= " << endl;
    gotoxy(45,4);cout << "Nama             : "; getline(cin, nama);
    gotoxy(45,5);cout << "Agama            : "; getline(cin, agm);
    gotoxy(45,6);cout << "Perguruan Tinggi : "; getline(cin, pgt);
    gotoxy(45,7);cout << "No.Hp            : "; getline(cin, hp);
	gotoxy(45,8);cout << "============================= " << endl;
    tambah_data(nama, agm, pgt, hp);
    gotoxy(45,9);cout << "  Data Berhasil di Tambahkan  " << endl;
    gotoxy(45,10);cout << "============================= " << endl;
    gotoxy(45,11);system("pause");
    
}
void ubah_data(string nama_lama, string nama_baru, string agm_baru, string pgt_baru, string hp_baru){
    ifstream file("coba.csv");
    ofstream file_temp("temp.csv");

    if(!file.is_open()){
        cout << "Gagal membuka file." << endl;
        return;
    }

    string nama, agm, pgt, hp;
    while (file.good()){  
        getline(file,nama,',');
        getline(file,agm,',');
        getline(file,pgt,',');
        getline(file,hp,'\n');

        if(nama == nama_lama){
            file_temp << nama_baru << "," << agm_baru << "," << pgt_baru << "," << hp_baru << endl;
        }
        else{
            file_temp << nama << "," << agm << "," << pgt << "," << hp << endl;
        }
    }  

    file.close();
    file_temp.close();

    // Menggantikan file original dengan file temporary
    remove("coba.csv");
    rename("temp.csv", "coba.csv");
}
void hapus_data(string nama){//menghapus data pada csv
    ifstream file("coba.csv");
    ofstream file_temp("temp.csv");

    if(!file.is_open()){
        cout << "Gagal membuka file." << endl;
        return;
    }

    string nama_dari_file, agm, pgt, hp;
    while (file.good()){  
        getline(file,nama_dari_file,',');
        getline(file,agm,',');
        getline(file,pgt,',');
        getline(file,hp,'\n');

        if(nama_dari_file != nama){
            file_temp << nama_dari_file << "," << agm << "," << pgt << "," << hp << endl;
        }
    }  

    file.close();
    file_temp.close();

    // Menggantikan file original dengan file temporary
    remove("coba.csv");
    rename("temp.csv", "coba.csv");
}


void tambahTamu(Node **head){//create tamu
fflush(stdin);
	Node *newNode = new Node();
	gotoxy(45,3);cout << "============================" << endl;
    gotoxy(45,3);cout << "         Data Tamu          " << endl; 
	gotoxy(45,4);cout << "============================" << endl;  
    gotoxy(45,5);cout << " Nama          : "; getline(cin, newNode->data1.nama); fflush(stdin); 
    gotoxy(45,6);cout << " Instansi      : "; getline(cin, newNode->data1.instansi);fflush(stdin); 
    gotoxy(45,7);cout << " Tujuan        : "; getline(cin, newNode->data1.tujuan);fflush(stdin); 
    gotoxy(45,8);cout << " No.Hp         : "; getline(cin, newNode->data1.hp);fflush(stdin);
	newNode->next = NULL;
    system("cls");
	if (*head == NULL){
        *head = newNode;
    } else {
        Node *temp = *head;
        while (temp->next != NULL){
            temp = temp->next;
        }
        temp->next = newNode;
    }
    gotoxy(45,9);cout << " =========================" << endl;
    gotoxy(45,10);cout << " Data berhasil ditambahkan" << endl;
    gotoxy(45,11);cout << " =========================" << endl;
    gotoxy(45,12);system("pause");
}

void tampilTamu(Node *head){// menampilkan daftar tamu
    if (head == NULL){
        gotoxy(45,3);cout << " ===================" << endl;
		gotoxy(45,4);cout << "   Tidak ada tamu   " << endl;
		gotoxy(45,5);cout << " ===================" << endl;
        gotoxy(45,6);system("pause");
        return;
    } else {
        Node *temp = head;
        int indeks;
        gotoxy(45,3);cout << "============================" << endl;
        gotoxy(45,4);cout << "          Daftar Tamu       " << endl;
        gotoxy(45,5);cout << "============================" << endl; fflush(stdin);
		for (indeks = 0; temp != NULL; indeks++){fflush(stdin);            
            cout << " Nama         : " << temp->data1.nama << endl;fflush(stdin);
            cout << " Instansi     : " << temp->data1.instansi << endl;fflush(stdin);
            cout << " Tujuan       : " << temp->data1.tujuan << endl;fflush(stdin);
            cout << " No.Hp        : " << temp->data1.hp << endl;fflush(stdin);
            cout << " =========================" << endl;
			temp = temp->next;
        }
         
        panjangList = indeks;
        system("pause");
    }
     
}

void hapusTamu(Node **head){
    if (*head == NULL){
    	gotoxy(45,3);cout << " ========================" << endl;
        gotoxy(45,4);cout << "        Data Kosong      " << endl;
        gotoxy(45,5);cout << " ========================" << endl;
		gotoxy(45,6);system("pause");
		system("cls");
    } else {
        Node *temp = *head;
        Node *prevTemp = temp;
        while (temp->next != NULL){
            prevTemp = temp;
            temp = temp->next;
        }
        if (temp == *head){
            *head = NULL;
        } else {
            prevTemp->next = NULL;
        }
        delete temp;
        panjangList--;
        gotoxy(45,3);cout << " ========================" << endl;
        gotoxy(45,4);cout << "    Data Telah Terhapus  " << endl;
        gotoxy(45,5);cout << " ========================" << endl;
        gotoxy(45,6);system("pause");
        system("cls");
    }
}
void ubahTamu(Node **head){
    string nohp;
    gotoxy(45,3);cout << "======================" << endl;
    gotoxy(45,4);cout << "   Masukkan No.HP :";cin >> nohp;
    gotoxy(45,6);cout << "======================" << endl;
	system("cls");
    Node *temp = *head;
    bool isFound = false;

    while(temp != NULL){
        if(temp->data1.hp == nohp){
        	gotoxy(45,3);cout << "=========================" << endl;
            gotoxy(45,4);cout << "  Data yang akan di Ubah  " << endl;
            gotoxy(45,5);cout << "=========================" << endl;
            gotoxy(45,6);cout << " Nama         : " << temp->data1.nama << endl;
            gotoxy(45,7);cout << " Instansi     : " << temp->data1.instansi << endl;
            gotoxy(45,8);cout << " Tujuan       : " << temp->data1.tujuan << endl;
            gotoxy(45,9);cout << " No.Hp        : " << temp->data1.hp << endl;
			gotoxy(45,10);cout << "=========================" << endl;
            gotoxy(45,11);cout << "   Masukkan Data Baru    " << endl;fflush(stdin);
            gotoxy(45,12);cout << "=========================" << endl;
            gotoxy(45,13);cout << "Nama          : "; getline(cin, temp->data1.nama);fflush(stdin);
            gotoxy(45,14);cout << "Instansi      : "; getline(cin, temp->data1.instansi);fflush(stdin);
            gotoxy(45,15);cout << "Tujuan        : "; getline(cin, temp->data1.tujuan);fflush(stdin);
            gotoxy(45,16);cout << "No.Hp         : "; getline(cin, temp->data1.hp);fflush(stdin);
            
            isFound = true;
            gotoxy(45,17);cout << "=========================" << endl;
        	gotoxy(45,18);cout << "    Data Telah di Ubah   " << endl;
        	gotoxy(45,19);cout << "=========================" << endl;
        	gotoxy(45,20);system("pause");
        	system("cls");
            break;
        }
        temp = temp->next;
        
    }
    

    if(!isFound){
    	gotoxy(45,3);cout << "==========================" << endl;
        gotoxy(45,4);cout << " No. HP Tidak di Temukan  " << endl;
        gotoxy(45,5);cout << "==========================" << endl;
        gotoxy(45,21);system("pause");
    	system("cls");
    }
    
}

void searchTamu(Node *head) {
    string name;
    gotoxy(45,3);cout << "=============================" << endl;
    gotoxy(45,4);cout << " Masukkan Nama : ";cin >> name;
    gotoxy(45,5);cout << "=============================" << endl;
    

    Node *temp = head;
    int index = 1;
    bool isFound = false;

    while (temp != NULL) {
        if (temp->data1.nama == name) {
            isFound = true;
            break;
        }
        temp = temp->next;
        index++;
    }

    if (isFound) {
    	gotoxy(40,3);cout << "==============================================================" << endl;
        gotoxy(40,4);cout << " Data ditemukan di Posisi [" << index << "] Dngan Informasi : " << endl;
        gotoxy(40,5);cout << "==============================================================" << endl;
        gotoxy(40,6);cout << " Nama         : " << temp->data1.nama << endl;
        gotoxy(40,7);cout << " Instansi     : " << temp->data1.instansi << endl;
        gotoxy(40,8);cout << " Tujuan       : " << temp->data1.tujuan << endl;
        gotoxy(40,9);cout << " No.Hp        : " << temp->data1.hp << endl;
        gotoxy(40,10);cout << "==============================================================" << endl;
        gotoxy(40,11);system("pause");
        system("cls");
    } else {
    	gotoxy(45,3);cout << "==================================" << endl;
        gotoxy(45,4);cout << "        Data Tidak Ditemukan      " << endl;
        gotoxy(45,5);cout << "==================================" << endl;
        gotoxy(45,6);system("pause");
        system("cls");
    }
    //gotoxy(45,11);system("pause");
}

void urutkanTamu(Node **head){
    Node *current = *head;
    string namaTemp;

    if (current == NULL || current->next == NULL){
    	gotoxy(45,3);cout << "============================" << endl;
    	gotoxy(45,4);cout << "         Data Kosong        " << endl;
    	gotoxy(45,5);cout << "============================" << endl;
		gotoxy(45,6);system("pause");
		system("cls");
        return;
    }

    while (current != NULL){//mengurutkan node berdasarkan nama
        Node *temp = current->next;
        while (temp != NULL){
            if (strcasecmp(current->data1.nama.c_str(), temp->data1.nama.c_str()) > 0){
                namaTemp = current->data1.nama;
                current->data1.nama = temp->data1.nama;
                temp->data1.nama = namaTemp;
            }
            temp = temp->next;
        }
        current = current->next;
    }
}


 
// prototype
struct Node *newNode(); // membuat node antrian baru
void display(Node *front);// menampilkan semua data antrian
void antriMasuk(Node **front, Node **rear);//menambahkan node baru ke akhir antrian
void antriKeluar(Node **front);// menghapus node awal pada antrian




main(){
	int pil;
	string id,pass;
	Node *FRONT = NULL, *REAR = NULL; 
	Node *HEAD = NULL;
	system("COLOR 1");
	do {
		gotoxy(45,4);cout << "=============================" << endl;
		gotoxy(45,5);cout << "   Sistem Pendataan Asrama   " << endl;
		gotoxy(45,6);cout << "=============================" << endl;
		gotoxy(45,7);cout << " 1. Admin " << endl;
		gotoxy(45,8);cout << " 2. Pengunjung " << endl;
		gotoxy(45,9);cout << " 0. Keluar" << endl;
		gotoxy(45,10);cout << "============================" << endl;
		gotoxy(45,12);cout << "============================" << endl;
		gotoxy(45,11);cout << " Pilihan : "; gotoxy(56,11.5);cin >> pil;
				
		system("cls");
		switch(pil) { 
			case 1:
				gotoxy(45,2);cout << "===========================" << endl;
				gotoxy(45,3);cout << "         Login Admin       " << endl;
				gotoxy(45,4);cout << "===========================" << endl;
				gotoxy(45,7);cout << "===========================" << endl;
				gotoxy(45,5);cout << " Masukkan ID       : "; cin >> id;
				gotoxy(45,6);cout << " Masukkan Password : "; cin >> pass;							
				system("cls");
				int pil1;
				if(id=="123"&&pass=="123") {
					do {
						gotoxy(45,2);cout << " ==========================" << endl;
						gotoxy(45,3);cout << "         Menu Admin        " << endl;
						gotoxy(45,4);cout << " ==========================" << endl;
						gotoxy(45,5);cout << " 1. Pendaftaran " << endl;
						gotoxy(45,6);cout << " 2. Data Penghuni Asrama" << endl;
						gotoxy(45,7);cout << " 3. Data Tamu" << endl;
						gotoxy(45,8);cout << " 0. Keluar" << endl;
						gotoxy(45,9);cout << " ==========================" << endl;
						gotoxy(45,11);cout << " ==========================" << endl;
						gotoxy(45,10);cout << " Pilihan : "; cin >> pil1;						
						system("cls");
						switch(pil1) {
							case 1:
								int pill1;
								do{
								gotoxy(45,2);cout << " ===================================" << endl;
								gotoxy(45,3);cout << "           Data Pendaftaran         " << endl;
								gotoxy(45,4);cout << " ===================================" << endl;
								gotoxy(45,5);cout << " 1. Tampilkan Data Antrian Pendaftar  " << endl;
								gotoxy(45,6);cout << " 2. Hapus Daftar " << endl;
								//gotoxy(45,7);cout << " 3. " << endl;
								gotoxy(45,7);cout << " 0. Kembali" << endl;
								gotoxy(45,8);cout << " ===================================" << endl;
								gotoxy(45,10);cout << " ===================================" << endl;
								gotoxy(45,9);cout << " Pilih : ";cin >> pill1;								
								system("cls");
								if(pill1 ==1 ){
									display(FRONT);
								}
								else if(pill1 ==2 ){
									antriKeluar(&FRONT);
								}
								
							}while(pill1 !=0 );
								break;

							case 2:
								int menu;    
									do{
    								gotoxy(45,3);cout << "============================= " << endl;
									gotoxy(45,4);cout << "     Data Penghuni Asrama     " << endl;
    								gotoxy(45,5);cout << "============================= " << endl;
									gotoxy(45,6);cout << "1. Tampilkan Data             " << endl;
    								gotoxy(45,7);cout << "2. Tambah Data                " << endl;
    								gotoxy(45,8);cout << "3. Hapus Data                 "<< endl;
								    gotoxy(45,9);cout << "4. Update atau Ubah Data      " << endl;
    								gotoxy(45,10);cout << "0. Kembali "<< endl;
    								gotoxy(45,11);cout << "============================= " << endl;
    								gotoxy(45,13);cout << "============================= " << endl;
									gotoxy(45,12);cout << "Pilih : "; cin >> menu;
									system("cls");
								switch(menu){
	
  							  	case 1:{
									asrama();								
    								break;
								}
    							case 2:{
        							menu2();
									break;
    							}
    							case 3:{
    								string nama;fflush(stdin);
    								gotoxy(45,3);cout <<"======================= " << endl;    								
    								gotoxy(45,4);cout << "Masukkan Nama : "; getline(cin, nama);fflush(stdin);
    								hapus_data(nama);fflush(stdin);
    								gotoxy(45,5);cout <<"======================== " << endl;
        							gotoxy(45,6);cout << "Data Berhasil di Hapus " << endl;
    								gotoxy(45,7);cout <<"======================== " << endl;
									gotoxy(45,8);system("pause");
    								break;
								}
								case 4:{
    								string nama_lama, nama_baru, agm_baru, pgt_baru, hp_baru; fflush(stdin);
    								gotoxy(45,3);cout << "============================= " << endl;
									gotoxy(45,4);cout << "Masukkan Nama Lama : "; getline (cin,nama_lama);
									gotoxy(45,5);cout << "============================= " << endl;
									gotoxy(45,6);cout << "    Update atau Ubah Data     " << endl;
									gotoxy(45,7);cout << "============================= " << endl; 
    								gotoxy(45,8);cout << "Nama               : "; getline (cin,nama_baru);
    								gotoxy(45,9);cout << "Agama              : "; getline(cin,agm_baru);
    								gotoxy(45,10);cout << "Perguruan Tinggi  : "; getline(cin,pgt_baru);
    								gotoxy(45,11);cout << "No.Hp             : "; getline(cin,hp_baru);
    								gotoxy(45,12);ubah_data(nama_lama, nama_baru, agm_baru, pgt_baru, hp_baru);    
    								gotoxy(45,13);cout << "============================= " << endl;
									gotoxy(45,14);cout << "     Data Berhasil Diubah     " << endl;
									gotoxy(45,15);cout << "============================= " << endl;
    								gotoxy(45,16);system("pause");
									break;
    							}
   					 			case 5:{   	
								break;
								}   
								}
								system("cls");
								}while(menu !=0);
								break;

							case 3:
								int tamu1;
								do{
								gotoxy(45,3);cout << " =====================" << endl;
								gotoxy(45,4);cout << "       Data Tamu      " << endl;
								gotoxy(45,5);cout << " =====================" << endl;
								gotoxy(45,6);cout << " 1. Tampilkan Data    " << endl;
								gotoxy(45,7);cout << " 2. Cari Data         " << endl;
								gotoxy(45,8);cout << " 3. Urutkan Data      " << endl;
								gotoxy(45,9);cout << " 4. Hapus Data        " << endl;
								gotoxy(45,10);cout << " 0. Kembali           " << endl;
								gotoxy(45,11);cout << " =====================" << endl;
								gotoxy(45,13);cout << " =====================" << endl;
								gotoxy(45,12);cout << " Pilihan :  "; cin >> tamu1;
								system("cls");
								switch(tamu1){
									case 1: tampilTamu(HEAD);
								      		system("cls");
								      		break;
									case 2: searchTamu(HEAD);
											break;
									case 3: urutkanTamu(&HEAD);
											break;
									case 4: hapusTamu(&HEAD); 
											break;
								}
								}while(tamu1 !=0 );
								
								break;

						}
						
					} while(pil1 != 0);
				} else {
					
					gotoxy(45,3);cout<<"ID atau Password Salah"<<endl;
					gotoxy(45,4);system("pause");
					system("cls");
				}


				break;
			case 2:
				int pil2;
				do{
					gotoxy(45,2);cout << " =======================" << endl;			
					gotoxy(45,3);cout << "      Menu Pengunjung   " << endl;
					gotoxy(45,4);cout << " =======================" << endl;
					gotoxy(45,5);cout << "  1. Mendaftar Anggota  " << endl;
					gotoxy(45,6);cout << "  2. Daftar Tamu        " << endl;
					gotoxy(45,7);cout << "  3. Info               " << endl;
					gotoxy(45,8);cout << "  0. Kembali            " << endl;
					gotoxy(45,9);cout << " =======================" << endl;
					gotoxy(45,11);cout << " =======================" << endl;
					gotoxy(45,10);cout << " Pilih :  "; cin >> pil2;
					
					system("cls");
					switch(pil2){
				case 1 :				
					antriMasuk(&FRONT, &REAR);
					
					break;
			    
				case 2:
					int tamu;
					do{
					gotoxy(45,3);cout << "======================" << endl;
					gotoxy(45,4);cout << "       Buku Tamu      " << endl;
			    	gotoxy(45,5);cout << "======================" << endl;
			    	gotoxy(45,6);cout << "1. Daftar Tamu        " << endl;
			    	gotoxy(45,7);cout << "2. Edit Data Diri     " << endl;
			    	gotoxy(45,8);cout << "0. Kembali            " << endl;
			    	gotoxy(45,9);cout << "======================" << endl;
					gotoxy(45,11);cout << "======================" << endl;
			    	gotoxy(45,10);cout << "Pilih  : "; cin >> tamu ;
			    	system("cls");
					switch(tamu){
					case 1:	tambahTamu(&HEAD);
					    	system("cls");
					    	break;
					case 2: ubahTamu(&HEAD);

							break;
					}
					}while(tamu != 0);
				break;
				
				case 3:
					gotoxy(45,3);cout << ">> Pendaftaran di buka pada tanggal 13 - 20 November <<" <<endl ; 
					gotoxy(45,4);cout << ">> Silahkan menghubungi admin untuk info selanjutnya no.hp 0852xxxxxxx <<" << endl;
					gotoxy(45,5);system("pause");
					system("cls");
					
					
					break;
			}
			}while(pil2 != 0);

		}
		system("cls");
	} while(pil != 0);
	gotoxy(45,3);cout << "Program Selesai ....";


}

Node *newNode() {//CREATE PENDAFTAR
	Node *nodeBaru = new Node();
	gotoxy(45,4);cout << " ==============================" << endl;
	gotoxy(45,3);cout << "          Masukkan Data        " << endl;
	gotoxy(45,4);cout << " ==============================" << endl; fflush(stdin);
	gotoxy(45,5);cout << "  Nama  : "; getline(cin, nodeBaru->data.nama); fflush(stdin);
	gotoxy(45,6);cout << "  Nik   : "; getline(cin, nodeBaru->data.nik);fflush(stdin);
	gotoxy(45,7);cout << "  Asal  : "; getline(cin, nodeBaru->data.asal); fflush(stdin);
	gotoxy(45,8);cout << "  No.Hp : "; getline(cin, nodeBaru->data.nohp);fflush(stdin);
	if(newNode != NULL){
		gotoxy(45,9);cout << " ==============================" << endl;
		gotoxy(45,10);cout << "   Data Berhasil ditambahkan   " << endl;
		gotoxy(45,11);cout << " ==============================" << endl;
	}
	gotoxy(45,12);system("pause");
	system("cls");
	return nodeBaru;
}

void display(Node *front) {//READ Data Pendaftar
	if (front == NULL) {// jika data null
		gotoxy(45,3);cout << "=============================" << endl;
		gotoxy(45,4);cout << "        Antrian Kosong"       << endl;
		gotoxy(45,5);cout << "=============================" << endl;
		gotoxy(45,6);system("pause");
		system("cls");
		return;
	}
		cout << " >>>> Data Pendaftar <<<<" << endl;
		cout << " ========================" << endl;
	while (front != NULL) {
		cout << " Nama   : " << front->data.nama << endl;
		cout << " NIK    : " << front->data.nik << endl;
		cout << " Asal   : " << front->data.asal << endl;
		cout << " No.Hp  : " << front->data.nohp << endl;
		cout << " ========================" << endl;
		front = front->next;		
		
	}
		system("pause");
		system("cls");
	cout << endl;
}

void antriMasuk(Node **front, Node **rear) {// menambahkan antrian pendaftar
	Node *nodeBaru = newNode();
	if (*front == NULL) {
		*front = nodeBaru;
	} else {
		(*rear)->next = nodeBaru;
	}
	*rear = nodeBaru;
}

void antriKeluar(Node **front) {// menghapus urutan antrian pendaftar
	if (*front == NULL) {
		gotoxy(45,3);cout << " =============================" << endl;
		gotoxy(45,4);cout << "      Tidak ada Pendaftar     " << endl;
		gotoxy(45,5);cout << " =============================" << endl;
		gotoxy(45,6);system("pause");
		return;
	}
	Node *temp = *front;
	*front = (*front)->next;
	delete temp;
		gotoxy(45,3);cout << " =============================" << endl;
		gotoxy(45,4);cout << "      Data Telah di Hapus     " << endl;
		gotoxy(45,5);cout << " =============================" << endl;
		system("pause");
	
	
}


